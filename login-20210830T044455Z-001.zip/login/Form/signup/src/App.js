import React from 'react';
import './App.css';
import Signup from './component/signup';

function App() {
  return (
    <Signup/>
    
  );
}

export default App;
